package com.example.retrofitnetworkcall

data  class News(val  totalResults:Int,val articles:List<Artical> )
