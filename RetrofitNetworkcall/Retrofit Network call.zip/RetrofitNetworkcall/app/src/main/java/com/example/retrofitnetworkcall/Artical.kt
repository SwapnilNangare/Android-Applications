package com.example.retrofitnetworkcall

import java.sql.Date
import java.util.stream.Stream

data class Artical(val author:String,val title:String,val description:String,val url:String,val urlToImage:String)
{
}